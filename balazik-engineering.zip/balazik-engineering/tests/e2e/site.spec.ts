import { test, expect } from '@playwright/test'

test.describe('Balazik Engineering Website', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000')
  })

  test('hero section renders with correct headline', async ({ page }) => {
    await expect(page.locator('h1')).toContainText('Engineering')
    await expect(page.locator('h1')).toContainText('Efficiency')
  })

  test('navigation is visible and contains key links', async ({ page }) => {
    const nav = page.locator('nav').first()
    await expect(nav).toBeVisible()
    await expect(page.locator('a[href="#problem"]')).toBeVisible()
    await expect(page.locator('a[href="#tools"]')).toBeVisible()
    await expect(page.locator('a[href="#contact"]')).toBeVisible()
  })

  test('energy loss calculator inputs are interactive', async ({ page }) => {
    await page.locator('#tools').scrollIntoViewIfNeeded()
    const velocitySlider = page.locator('input[type="range"]').first()
    await expect(velocitySlider).toBeVisible()
    await velocitySlider.fill('200')
  })

  test('flow visualization mode buttons work', async ({ page }) => {
    const turbBtn = page.getByRole('button', { name: /turbulent/i })
    await turbBtn.scrollIntoViewIfNeeded()
    await turbBtn.click()
    await expect(turbBtn).toHaveClass(/bg-\[var/)
  })

  test('system selector switches content', async ({ page }) => {
    await page.locator('#systems').scrollIntoViewIfNeeded()
    await page.getByRole('button', { name: /Marine Vessel/i }).click()
    await expect(page.getByText(/Hull wetted surface/i)).toBeVisible()
  })

  test('contact form is submittable', async ({ page }) => {
    await page.locator('#contact').scrollIntoViewIfNeeded()
    await page.fill('input[placeholder="Your name"]', 'Test Engineer')
    await page.fill('input[placeholder="your@email.com"]', 'test@example.com')
    await page.fill('textarea', 'Testing the contact form for an engineering consultation.')
    await page.getByRole('button', { name: /Send Message/i }).click()
    await expect(page.getByText(/Message received/i)).toBeVisible()
  })

  test('page has no console errors', async ({ page }) => {
    const errors: string[] = []
    page.on('console', msg => {
      if (msg.type() === 'error') errors.push(msg.text())
    })
    await page.waitForLoadState('networkidle')
    expect(errors.filter(e => !e.includes('Warning:'))).toHaveLength(0)
  })

  test('navigation link scrolls to correct section', async ({ page }) => {
    await page.locator('a[href="#problem"]').click()
    await expect(page.locator('#problem')).toBeInViewport({ ratio: 0.3 })
  })

})
