import { test, expect } from '@playwright/test'

// All pages now live under /en (default locale)
const BASE = '/en'

test.describe('Balazik Engineering — E2E Tests', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto(BASE)
  })

  // ── Hero Section ──────────────────────────────────────────────────
  test('hero section renders headline and author name', async ({ page }) => {
    await expect(page.getByText('Engineering')).toBeVisible()
    await expect(page.getByText('Pavol Balazik')).toBeVisible()
    await expect(page.getByText('Independent Systems Architect')).toBeVisible()
  })

  test('hero expertise tags are visible', async ({ page }) => {
    const tags = ['Energy Systems', 'Friction Reduction', 'Hydrodynamics', 'Aerodynamics', 'System Optimization']
    for (const tag of tags) {
      await expect(page.getByText(tag)).toBeVisible()
    }
  })

  // ── Navigation ────────────────────────────────────────────────────
  test('navigation contains all expected links', async ({ page }) => {
    const navLabels = ['Problem', 'Fields', 'Analysis', 'Tools', 'Systems', 'Philosophy', 'Contact']
    for (const label of navLabels) {
      await expect(page.getByRole('link', { name: label })).toBeVisible()
    }
  })

  test('navigation scrolls to section on click', async ({ page }) => {
    await page.getByRole('link', { name: 'Problem' }).first().click()
    await page.waitForTimeout(800)
    const section = page.locator('#problem')
    await expect(section).toBeInViewport()
  })

  test('navigation becomes opaque on scroll', async ({ page }) => {
    await page.evaluate(() => window.scrollTo(0, 200))
    await page.waitForTimeout(400)
    const nav = page.locator('nav').first()
    const bg = await nav.evaluate(el => getComputedStyle(el).backgroundColor)
    expect(bg).not.toBe('rgba(0, 0, 0, 0)')
  })

  // ── Language Switcher ─────────────────────────────────────────────
  test('language switcher shows EN SK DE buttons', async ({ page }) => {
    await expect(page.getByRole('link', { name: 'Switch to EN' })).toBeVisible()
    await expect(page.getByRole('link', { name: 'Switch to SK' })).toBeVisible()
    await expect(page.getByRole('link', { name: 'Switch to DE' })).toBeVisible()
  })

  test('switching to Slovak changes URL to /sk', async ({ page }) => {
    await page.getByRole('link', { name: 'Switch to SK' }).click()
    await page.waitForURL(/\/sk/)
    expect(page.url()).toContain('/sk')
  })

  test('switching to German changes URL to /de', async ({ page }) => {
    await page.getByRole('link', { name: 'Switch to DE' }).click()
    await page.waitForURL(/\/de/)
    expect(page.url()).toContain('/de')
  })

  test('Slovak page shows Slovak navigation labels', async ({ page }) => {
    await page.goto('/sk')
    await expect(page.getByText('Problém')).toBeVisible()
    await expect(page.getByText('Kontakt')).toBeVisible()
  })

  test('German page shows German navigation labels', async ({ page }) => {
    await page.goto('/de')
    await expect(page.getByText('Problem')).toBeVisible()
    await expect(page.getByText('Kontakt')).toBeVisible()
  })

  // ── Problem Section ───────────────────────────────────────────────
  test('problem section displays loss categories', async ({ page }) => {
    await page.locator('#problem').scrollIntoViewIfNeeded()
    const categories = ['Friction', 'Turbulence', 'Drag', 'Hidden Losses']
    for (const cat of categories) {
      await expect(page.getByText(cat)).toBeVisible()
    }
  })

  // ── Energy Loss Calculator ────────────────────────────────────────
  test('calculator renders with default inputs', async ({ page }) => {
    await page.locator('#tools').scrollIntoViewIfNeeded()
    await expect(page.getByText('Energy Loss Calculator')).toBeVisible()
    await expect(page.locator('select')).toBeVisible()
  })

  test('calculator updates results when velocity changes', async ({ page }) => {
    await page.locator('#tools').scrollIntoViewIfNeeded()
    const velocitySlider = page.locator('input[type="range"]').first()
    const initial = await page.getByText(/N$/).first().textContent()
    await velocitySlider.evaluate(el => {
      (el as HTMLInputElement).value = '200'
      el.dispatchEvent(new Event('input', { bubbles: true }))
    })
    await page.waitForTimeout(500)
    const updated = await page.getByText(/N$/).first().textContent()
    expect(updated).not.toBe(initial)
  })

  test('calculator system type selector changes outputs', async ({ page }) => {
    await page.locator('#tools').scrollIntoViewIfNeeded()
    await page.locator('select').selectOption('ship')
    await page.waitForTimeout(300)
    await expect(page.getByText('Marine Vessel')).toBeVisible()
  })

  // ── Flow Visualization ────────────────────────────────────────────
  test('flow visualization renders with mode buttons', async ({ page }) => {
    await page.getByText('Laminar Flow').first().scrollIntoViewIfNeeded()
    await expect(page.getByText('Laminar Flow').first()).toBeVisible()
    await expect(page.getByText('Turbulent Flow').first()).toBeVisible()
    await expect(page.getByText('Boundary Layer').first()).toBeVisible()
  })

  test('flow visualization switches mode on button click', async ({ page }) => {
    await page.getByText('Turbulent Flow').first().click()
    await page.waitForTimeout(300)
    const turbBtn = page.getByText('Turbulent Flow').first()
    const bg = await turbBtn.evaluate(el => getComputedStyle(el).backgroundColor)
    expect(bg).not.toBe('rgba(0, 0, 0, 0)')
  })

  // ── Systems Section ───────────────────────────────────────────────
  test('systems section tabs switch content', async ({ page }) => {
    await page.locator('#systems').scrollIntoViewIfNeeded()
    await page.getByRole('button', { name: 'Marine Vessel' }).click()
    await page.waitForTimeout(400)
    await expect(page.getByText('Wave-making resistance')).toBeVisible()
  })

  // ── Contact Section ───────────────────────────────────────────────
  test('contact section renders form fields', async ({ page }) => {
    await page.locator('#contact').scrollIntoViewIfNeeded()
    await expect(page.getByPlaceholder('Your name')).toBeVisible()
    await expect(page.getByPlaceholder('your@email.com')).toBeVisible()
  })

  test('contact form shows confirmation on submit', async ({ page }) => {
    await page.locator('#contact').scrollIntoViewIfNeeded()
    await page.getByPlaceholder('Your name').fill('Test Engineer')
    await page.getByPlaceholder('your@email.com').fill('test@example.com')
    await page.getByPlaceholder(/Describe the system/).fill('Testing contact form.')
    await page.getByRole('button', { name: /Send Message/ }).click()
    await expect(page.getByText('Message received')).toBeVisible()
  })

  test('LinkedIn link points to correct URL', async ({ page }) => {
    await page.locator('#contact').scrollIntoViewIfNeeded()
    const linkedinLink = page.getByRole('link', { name: /LinkedIn/ })
    const href = await linkedinLink.getAttribute('href')
    expect(href).toBe('https://www.linkedin.com/in/pavol-balazik-512a71247 )
  })

  // ── Responsiveness ────────────────────────────────────────────────
  test('page is responsive on mobile viewport', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 })
    await expect(page.getByText('Pavol Balazik')).toBeVisible()
    await expect(page.getByText('Engineering')).toBeVisible()
  })

  // ── Accessibility ─────────────────────────────────────────────────
  test('page has correct title', async ({ page }) => {
    const title = await page.title()
    expect(title).toContain('Pavol Balazik')
    expect(title).toContain('Engineering Systems Architect')
  })

  test('canvases have aria-label attributes', async ({ page }) => {
    const canvases = page.locator('canvas[aria-label]')
    const count = await canvases.count()
    expect(count).toBeGreaterThan(0)
  })

  test('html lang attribute matches active locale', async ({ page }) => {
    const lang = await page.locator('html').getAttribute('lang')
    expect(lang).toBe('en')
  })

  test('Slovak page has lang=sk', async ({ page }) => {
    await page.goto('/sk')
    const lang = await page.locator('html').getAttribute('lang')
    expect(lang).toBe('sk')
  })

  // ── Performance ───────────────────────────────────────────────────
  test('page loads within 5 seconds', async ({ page }) => {
    const start = Date.now()
    await page.goto(BASE, { waitUntil: 'domcontentloaded' })
    const duration = Date.now() - start
    expect(duration).toBeLessThan(5000)
  })

  // ── Root redirect ─────────────────────────────────────────────────
  test('root "/" redirects to /en', async ({ page }) => {
    await page.goto('/')
    await page.waitForURL(/\/en/)
    expect(page.url()).toContain('/en')
  })
})
