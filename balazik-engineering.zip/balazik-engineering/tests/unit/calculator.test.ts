/**
 * Unit tests — Energy Loss Calculator logic
 */

type SystemType = 'vehicle' | 'ship' | 'aircraft' | 'pipeline' | 'industrial'

const SYSTEM_PARAMS: Record<SystemType, { cd: number; cf: number; turbFactor: number }> = {
  vehicle:    { cd: 0.30, cf: 0.015, turbFactor: 0.12 },
  ship:       { cd: 0.60, cf: 0.003, turbFactor: 0.22 },
  aircraft:   { cd: 0.025, cf: 0.004, turbFactor: 0.08 },
  pipeline:   { cd: 0.02, cf: 0.018, turbFactor: 0.18 },
  industrial: { cd: 0.15, cf: 0.025, turbFactor: 0.20 },
}

function calcResults(systemType: SystemType, velocity: number, surfaceArea: number, power: number) {
  const params = SYSTEM_PARAMS[systemType]
  const rho = systemType === 'ship' ? 1025 : 1.225
  const v = velocity / 3.6
  const aeroDrag = 0.5 * rho * v * v * params.cd * surfaceArea
  const frictionLoss = power * 1000 * params.cf
  const turbulenceLoss = power * 1000 * params.turbFactor
  const totalLoss = aeroDrag * v + frictionLoss + turbulenceLoss
  const totalPowerW = power * 1000
  const efficiency = Math.max(20, Math.min(95, ((totalPowerW - totalLoss) / totalPowerW) * 100))
  const optimisationPotential = Math.min(40, (100 - efficiency) * 0.6)
  return {
    aeroDrag: Math.round(aeroDrag),
    frictionLoss: Math.round(frictionLoss / 1000),
    turbulenceLoss: Math.round(turbulenceLoss / 1000),
    totalLoss: Math.round(totalLoss / 1000),
    efficiency: Math.round(efficiency * 10) / 10,
    optimisationPotential: Math.round(optimisationPotential * 10) / 10,
  }
}

describe('Energy Loss Calculator', () => {
  it('produces non-zero aerodynamic drag for vehicle', () => {
    expect(calcResults('vehicle', 120, 2.2, 150).aeroDrag).toBeGreaterThan(0)
  })
  it('efficiency is within valid range', () => {
    const r = calcResults('vehicle', 120, 2.2, 150)
    expect(r.efficiency).toBeGreaterThanOrEqual(0)
    expect(r.efficiency).toBeLessThanOrEqual(100)
  })
  it('higher velocity produces higher drag', () => {
    const lo = calcResults('vehicle', 60, 2.2, 150)
    const hi = calcResults('vehicle', 200, 2.2, 150)
    expect(hi.aeroDrag).toBeGreaterThan(lo.aeroDrag)
  })
  it('optimisation potential is 0-40', () => {
    const r = calcResults('vehicle', 100, 5, 1000)
    expect(r.optimisationPotential).toBeGreaterThanOrEqual(0)
    expect(r.optimisationPotential).toBeLessThanOrEqual(40)
  })
  it('efficiency clamped to min 20%', () => {
    expect(calcResults('ship', 400, 1000, 10).efficiency).toBeGreaterThanOrEqual(20)
  })
})
