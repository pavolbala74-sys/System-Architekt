/**
 * Unit tests for Engineering components
 */

// Mock framer-motion to avoid animation issues in test env
jest.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: React.HTMLAttributes<HTMLDivElement> & { children?: React.ReactNode }) =>
      require('react').createElement('div', props, children),
    h1: ({ children, ...props }: React.HTMLAttributes<HTMLHeadingElement> & { children?: React.ReactNode }) =>
      require('react').createElement('h1', props, children),
    h2: ({ children, ...props }: React.HTMLAttributes<HTMLHeadingElement> & { children?: React.ReactNode }) =>
      require('react').createElement('h2', props, children),
    p:  ({ children, ...props }: React.HTMLAttributes<HTMLParagraphElement> & { children?: React.ReactNode }) =>
      require('react').createElement('p', props, children),
    span: ({ children, ...props }: React.HTMLAttributes<HTMLSpanElement> & { children?: React.ReactNode }) =>
      require('react').createElement('span', props, children),
    nav: ({ children, ...props }: React.HTMLAttributes<HTMLElement> & { children?: React.ReactNode }) =>
      require('react').createElement('nav', props, children),
    circle: ({ children, ...props }: React.SVGAttributes<SVGCircleElement> & { children?: React.ReactNode }) =>
      require('react').createElement('circle', props, children),
    line: (props: React.SVGAttributes<SVGLineElement>) =>
      require('react').createElement('line', props),
    path: (props: React.SVGAttributes<SVGPathElement>) =>
      require('react').createElement('path', props),
  },
  AnimatePresence: ({ children }: { children: React.ReactNode }) => children,
  useInView: () => true,
  useMotionValue: (init: number) => ({ get: () => init, set: () => {} }),
  useTransform: () => ({ get: () => 0 }),
}))

import React from 'react'
import { render, screen } from '@testing-library/react'

// ─── Navigation ──────────────────────────────────────────────────────
describe('Navigation', () => {
  it('renders brand name', async () => {
    const { default: Navigation } = await import('../app/components/Navigation')
    render(<Navigation />)
    expect(screen.getByText(/Pavol/i)).toBeInTheDocument()
  })

  it('renders all nav items', async () => {
    const { default: Navigation } = await import('../app/components/Navigation')
    render(<Navigation />)
    expect(screen.getByText('Problem')).toBeInTheDocument()
    expect(screen.getByText('Fields')).toBeInTheDocument()
    expect(screen.getByText('Contact')).toBeInTheDocument()
  })

  it('renders Engage CTA link', async () => {
    const { default: Navigation } = await import('../app/components/Navigation')
    render(<Navigation />)
    const cta = screen.getAllByText(/engage/i)
    expect(cta.length).toBeGreaterThan(0)
  })
})

// ─── Hero Section ────────────────────────────────────────────────────
describe('HeroSection', () => {
  it('renders main headline', async () => {
    const { default: HeroSection } = await import('../app/components/sections/HeroSection')
    render(<HeroSection />)
    expect(screen.getByText(/Engineering/i)).toBeInTheDocument()
  })

  it('renders architect title', async () => {
    const { default: HeroSection } = await import('../app/components/sections/HeroSection')
    render(<HeroSection />)
    expect(screen.getByText(/Independent Systems Architect/i)).toBeInTheDocument()
  })

  it('renders all expertise tags', async () => {
    const { default: HeroSection } = await import('../app/components/sections/HeroSection')
    render(<HeroSection />)
    expect(screen.getByText('Energy Systems')).toBeInTheDocument()
    expect(screen.getByText('Hydrodynamics')).toBeInTheDocument()
    expect(screen.getByText('Aerodynamics')).toBeInTheDocument()
  })
})

// ─── Problem Section ─────────────────────────────────────────────────
describe('ProblemSection', () => {
  it('renders section heading', async () => {
    const { default: ProblemSection } = await import('../app/components/sections/ProblemSection')
    render(<ProblemSection />)
    expect(screen.getByText(/waste/i)).toBeInTheDocument()
  })

  it('renders loss type labels', async () => {
    const { default: ProblemSection } = await import('../app/components/sections/ProblemSection')
    render(<ProblemSection />)
    expect(screen.getByText('Friction')).toBeInTheDocument()
    expect(screen.getByText('Turbulence')).toBeInTheDocument()
    expect(screen.getByText('Drag')).toBeInTheDocument()
  })
})

// ─── Fields Section ──────────────────────────────────────────────────
describe('FieldsSection', () => {
  it('renders all six domains', async () => {
    const { default: FieldsSection } = await import('../app/components/sections/FieldsSection')
    render(<FieldsSection />)
    expect(screen.getByText('Energy Loss Diagnostics')).toBeInTheDocument()
    expect(screen.getByText('Friction & Surface Interaction')).toBeInTheDocument()
    expect(screen.getByText('Hydrodynamic Flow Optimization')).toBeInTheDocument()
    expect(screen.getByText('Aerodynamic Efficiency')).toBeInTheDocument()
    expect(screen.getByText('Mechanical System Architecture')).toBeInTheDocument()
    expect(screen.getByText('Industrial Efficiency Systems')).toBeInTheDocument()
  })
})

// ─── Tools Section ───────────────────────────────────────────────────
describe('ToolsSection', () => {
  it('renders calculator heading', async () => {
    const { default: ToolsSection } = await import('../app/components/sections/ToolsSection')
    render(<ToolsSection />)
    expect(screen.getByText('Energy Loss Calculator')).toBeInTheDocument()
  })

  it('renders system type select', async () => {
    const { default: ToolsSection } = await import('../app/components/sections/ToolsSection')
    render(<ToolsSection />)
    expect(screen.getByText('Road Vehicle')).toBeInTheDocument()
  })

  it('renders results section', async () => {
    const { default: ToolsSection } = await import('../app/components/sections/ToolsSection')
    render(<ToolsSection />)
    expect(screen.getByText('Analysis Results')).toBeInTheDocument()
  })
})

// ─── Systems Section ─────────────────────────────────────────────────
describe('SystemsSection', () => {
  it('renders all system tabs', async () => {
    const { default: SystemsSection } = await import('../app/components/sections/SystemsSection')
    render(<SystemsSection />)
    expect(screen.getByText('Road Vehicle')).toBeInTheDocument()
    expect(screen.getByText('Marine Vessel')).toBeInTheDocument()
    expect(screen.getByText('Pumping System')).toBeInTheDocument()
    expect(screen.getByText('Aircraft')).toBeInTheDocument()
  })
})

// ─── Research Section ────────────────────────────────────────────────
describe('ResearchSection', () => {
  it('renders all concept IDs', async () => {
    const { default: ResearchSection } = await import('../app/components/sections/ResearchSection')
    render(<ResearchSection />)
    expect(screen.getByText('EDLS')).toBeInTheDocument()
    expect(screen.getByText('FOM')).toBeInTheDocument()
    expect(screen.getByText('MEA')).toBeInTheDocument()
  })
})

// ─── Philosophy Section ──────────────────────────────────────────────
describe('PhilosophySection', () => {
  it('renders core quote', async () => {
    const { PhilosophySection } = await import('../app/components/sections/PhilosophyContactSections')
    render(<PhilosophySection />)
    expect(screen.getByText(/hidden inefficiencies/i)).toBeInTheDocument()
  })
})

// ─── Contact Section ─────────────────────────────────────────────────
describe('ContactSection', () => {
  it('renders form fields', async () => {
    const { ContactSection } = await import('../app/components/sections/PhilosophyContactSections')
    render(<ContactSection />)
    expect(screen.getByPlaceholderText('Your name')).toBeInTheDocument()
    expect(screen.getByPlaceholderText('your@email.com')).toBeInTheDocument()
  })

  it('renders submit button', async () => {
    const { ContactSection } = await import('../app/components/sections/PhilosophyContactSections')
    render(<ContactSection />)
    expect(screen.getByText('Send Message')).toBeInTheDocument()
  })
})
