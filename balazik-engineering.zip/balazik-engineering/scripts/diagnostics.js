#!/usr/bin/env node
const fs = require('fs')
const path = require('path')

const LOG_FILE = path.join(__dirname, '..', 'diagnostics.log')
const ROOT = path.join(__dirname, '..')

let passed = 0, failed = 0
const log = []

function check(name, fn) {
  try {
    const r = fn()
    if (r !== false) { passed++; log.push(`  ✓  ${name}`) }
    else { failed++; log.push(`  ✗  ${name}`) }
  } catch (e) { failed++; log.push(`  ✗  ${name}: ${e.message}`) }
}

const fe = (r) => fs.existsSync(path.join(ROOT, r))

log.push('\n── Project Structure ──────────────────────────────')
;['package.json','tsconfig.json','next.config.js','tailwind.config.ts','app/layout.tsx','app/page.tsx','app/styles/globals.css']
  .forEach(f => check(f, () => fe(f)))

log.push('\n── Section Components ─────────────────────────────')
;['HeroSection','ProblemSection','FieldsSection','QuestionsSection','AnalysisSection',
  'FlowVisualizationSection','ToolsSection','SystemsSection','ResearchSection','PhilosophyContactSections']
  .forEach(s => check(s, () => fe(`app/components/sections/${s}.tsx`)))

log.push('\n── Navigation ─────────────────────────────────────')
check('Navigation.tsx', () => fe('app/components/Navigation.tsx'))

log.push('\n── Tests ──────────────────────────────────────────')
check('Unit tests', () => fe('tests/unit/components.test.tsx'))
check('E2E tests',  () => fe('tests/e2e/site.spec.ts'))
check('Playwright config', () => fe('playwright.config.ts'))

log.push('\n── CI Pipeline ────────────────────────────────────')
check('GitHub Actions', () => fe('.github/workflows/ci.yml'))

log.push('\n── Package Dependencies ───────────────────────────')
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'))
;['next','react','framer-motion','three','chart.js','tailwindcss']
  .forEach(d => check(d, () => !!(pkg.dependencies?.[d] || pkg.devDependencies?.[d])))

log.push('\n── NPM Scripts ────────────────────────────────────')
;['dev','build','test','lint','type-check']
  .forEach(s => check(`script:${s}`, () => !!pkg.scripts?.[s]))

const total = passed + failed
log.push('\n══════════════════════════════════════════════════')
log.push(`  Diagnostics: ${passed}/${total} passed`)
log.push(failed > 0 ? `  ⚠  ${failed} failed` : '  ✓  All checks passed')
log.push('══════════════════════════════════════════════════\n')

const out = log.join('\n')
console.log(out)
fs.writeFileSync(LOG_FILE, out)
if (failed > 0) process.exit(1)
